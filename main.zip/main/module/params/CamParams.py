class CamParams:
    def __init__(self, width, height):
        self.width = width
        self.height = height
